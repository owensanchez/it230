﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Course choice;


        public MainWindow()
        {
            InitializeComponent();
        }

        // Returns the total number of credits for which the student is registered
        private int GetTotalCredits()
        {
            int sum = 0;
            // Add 3 credits per registered course
            foreach (Course c in this.listBox.Items)
            {
                sum += 3;
            }
            return sum;
        }

        // Updates the credit count in the UI
        private void UpdateCreditCount()
        {
            this.textBox.Text = Convert.ToString(GetTotalCredits());
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");


            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);


            // Update the credit count to its initial value
            UpdateCreditCount();
        }

        // Sets the status text for when the user attempts to register for a course
        private void SetStatusMessage(string text)
        {
            this.label3.Content = text;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Get the user's choice
            choice = (Course)(this.comboBox.SelectedItem);

            // Check that the user selected a course
            if (choice == null)
            {
                SetStatusMessage("Please select a course first.");
                return;
            }

            // Prevent the user from registering for too many courses
            if (this.listBox.Items.Count >= 3)
            {
                SetStatusMessage("You cannot register for more than 9 credit hours.");
                return;
            }

            // Prevent the user from registering for the same course more than once
            if (choice.IsRegisteredAlready())
            {
                SetStatusMessage("You have already registered for the " + choice.getName() + " course.");
                return;
            }

            // Mark the course as registered
            choice.SetToRegistered();
            // Add the course to the registration list
            this.listBox.Items.Add(choice);
            // Update the credit count
            UpdateCreditCount();
            // Display a confirmation message
            SetStatusMessage("Registration confirmed for " + choice.getName());
        }

    }
}
